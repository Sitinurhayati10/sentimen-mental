
import streamlit as st
import joblib
import re
import requests
from urllib.parse import urlparse, parse_qs
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory

st.set_page_config(page_title="Sentimen Mental", page_icon="🧠")

# Load model
model = joblib.load("xgboost_model.pkl")
tfidf = joblib.load("tfidf_vectorizer.pkl")
label_encoder = joblib.load("label_encoder.pkl")

stemmer = StemmerFactory().create_stemmer()
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    return stemmer.stem(text)

# --- Halaman utama --- #
st.title("🧠 Analisis Sentimen Status Facebook")
st.markdown("Login melalui tombol di bawah ini:")

# Link login Facebook OAuth
APP_ID = "1874696633376685"
REDIRECT_URI = "https://sentimen-mental.streamlit.app/fb_login"
OAUTH_URL = f"https://www.facebook.com/v18.0/dialog/oauth?client_id={APP_ID}&redirect_uri={REDIRECT_URI}&scope=user_posts&response_type=token"

st.markdown(f"[🔗 Login dengan Facebook]({OAUTH_URL})", unsafe_allow_html=True)

# Cek apakah access token ada di URL
query_params = st.query_params
if "access_token" in query_params:
    access_token = query_params["access_token"]
    st.success("Berhasil login! 🎉")

    # Ambil status dari Graph API
    st.subheader("📥 Ambil Status Terbaru dari Facebook")
    user_posts_url = f"https://graph.facebook.com/v18.0/me/posts?access_token={access_token}"
    resp = requests.get(user_posts_url)
    if resp.status_code == 200:
        posts = resp.json().get("data", [])
        for i, post in enumerate(posts[:5]):
            msg = post.get("message", "(tidak ada teks)")
            st.markdown(f"**Status {i+1}:** {msg}")
            bersih = clean_text(msg)
            vektor = tfidf.transform([bersih])
            hasil = model.predict(vektor)
            label = label_encoder.inverse_transform(hasil)[0]
            st.info(f"📊 Sentimen: **{label}**")
    else:
        st.error("Gagal mengambil status. Pastikan token valid & memiliki izin.")
else:
    st.warning("🔐 Belum login. Access token tidak ditemukan.")
